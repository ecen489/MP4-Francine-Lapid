package com.example.newcalculator;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up spinner
        final Spinner spinner = (Spinner) findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.operations_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Set up EditText
        EditText numArg1 = (EditText) findViewById(R.id.arg1);
        EditText numArg2 = (EditText) findViewById(R.id.arg2);

        final Editable arg1_editable = numArg1.getText();
        final Editable arg2_editable = numArg2.getText();

        // Set up TextView
        final TextView resultScreen = (TextView) findViewById(R.id.textView);

        // Set up Button
        final Button resultButton = (Button) findViewById(R.id.equalsButton);
        resultButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String arg1_string = arg1_editable.toString();
                String arg2_string = arg2_editable.toString();

                if(!TextUtils.isEmpty(arg1_string) && !TextUtils.isEmpty(arg2_string)) {
                    double arg1 = Double.valueOf(arg1_string);
                    double arg2 = Double.valueOf(arg2_string);
                    // user wants to add
                    if (spinner.getSelectedItem().equals("+")) {
                        double sum = arg1 + arg2;
                        resultScreen.setText(String.valueOf(sum));
                    }
                    // user wants to subtract
                    else if (spinner.getSelectedItem().equals("-")) {
                        double diff = arg1 - arg2;
                        resultScreen.setText(String.valueOf(diff));
                    }
                    // user wants to multiply
                    else {
                        double prod = arg1 * arg2;
                        resultScreen.setText(String.valueOf(prod));
                    }
                }
                else {
                    resultScreen.setText("PUT IN NUMBER PLEASE");
                }


            }
        });
    }
}
